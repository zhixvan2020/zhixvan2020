?php
$token=$_POST['token'];
$secret='6LfuVtcUAAAAABiiey80VcRjcgPJBQgSZR9FfbEH';

$value = http_post("https://www.recaptcha.net/recaptcha/api/siteverify",'secret='.$secret.'&response='.$token);//参数建议用与符号拼接

echo $value;



function http_post($url,$postbody){
    $curl = curl_init();
    curl_setopt($curl,CURLOPT_URL,$url);
    // CURLOPT_RETURNTRANSFER  设置是否有返回值
    curl_setopt($curl,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($curl,CURLOPT_POST,true);
    curl_setopt($curl,CURLOPT_POSTFIELDS,$postbody);
    //执行完以后的返回值
    $response = curl_exec($curl);
    //释放curl
    curl_close($curl);
    return $response;
}
?>
